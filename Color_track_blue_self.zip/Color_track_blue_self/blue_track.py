# 导入必要的库
import numpy as np
import cv2
import serial
import math
import time

#参数定义
lower_blue = np.array([100, 80, 70])# 蓝色的下限
upper_blue = np.array([115, 255, 255])# 蓝色的上限

lower_red1 = np.array([0, 130, 100])# 浅红色的下限1
upper_red1 = np.array([15, 255, 255])# 浅红色的上限1
lower_red2 = np.array([170, 130, 100])# 深红色的下限2
upper_red2 = np.array([180, 255, 255])# 深红色的上限2

lower_black = np.array([0, 0, 0])# 黑色的下限
upper_black = np.array([180, 255, 10])# 黑色的上限

#坐标参数
ex,ey = 0,0
x,y=None,None
w,h=None,None
x0,y0=None,None

#创建掩码,默认为创建蓝色掩码
def create_mask(frame,lower1=lower_blue, upper1=upper_blue,lower2=None,upper2=None):
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    mask1 =cv2.inRange(hsv, lower1, upper1)

    if lower2 is not None and upper2 is not None:
        mask2 = cv2.inRange(hsv, lower2, upper2)
        mask = cv2.bitwise_or(mask1, mask2)
    else:
        mask = mask1

    return mask

#形态学操作,先开后比较好，能去除小的噪点，同时保持目标的完整性
def morphological_operations(mask):
    kernel = np.ones((5,5),np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=2)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    return mask

# 查找最圆轮廓
def find_circle_contours(contours,min_area=500):
    best_cnt=None
    best_c=0.0
    best_center=None
    best_r=0.0

    for cnt in contours:
        area= cv2.contourArea(cnt)
        if area<min_area:
            continue

        peri =cv2.arcLength(cnt,True)
        if peri <=1e-6:
            continue

        c= 4.0*math.pi*area/peri**2
        if c>best_c:
            best_c=c
            best_cnt=cnt
            (x,y),r=cv2.minEnclosingCircle(cnt)
            best_center = (int(round(x)), int(round(y)))
            best_r = float(r)
    return best_cnt,best_center,best_r

#打开串口
def open_serial(port='COM3', rate=9600):
    try:
        ser = serial.Serial(port,rate)
        print(f"成功打开串口 {port}，波特率 {rate}")
        return ser
    except serial.SerialException as e:
        print(f"错误，无法打开串口 {port}: {e}")
        return None


def main():
    ser = open_serial("COM3")
    if ser is None:
        return
    cap = cv2.VideoCapture(1)#根据实际情况调整摄像头索引
    while True:
        ret, frame = cap.read()
        if not ret:
            time.sleep(1)
            continue
        h, w = frame.shape[:2]
        x0, y0 = int((w / 2)), int((h / 2))
        mask=create_mask(frame,lower1=lower_blue,upper1=upper_blue)
        mask=morphological_operations(mask)
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        best_cnt,best_center,best_r=find_circle_contours(contours)

        #展示结果
        display_frame=frame.copy()
        #绘制窗口中心
        cv2.line(display_frame,(x0-10,y0),(x0+10,y0),(0,255,255),2)
        cv2.line(display_frame,(x0,y0-10),(x0,y0+10),(0,255,255),2)

        #绘制目标
        if best_cnt is not None and best_center is not None:
            x,y=best_center
            cv2.circle(display_frame,best_center,int(best_r),(0,255,0),2)
            cv2.line(display_frame,(x-10,y),(x+10,y),(0,255,0),2)
            cv2.line(display_frame,(x,y-10),(x,y+10),(0,255,0),2)

            #显示坐标
            info_text = f"Target: ({x}, {y}), Radius: {best_r}"
            cv2.putText(display_frame, info_text, (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
            #绘制连线
            cv2.line(display_frame,(x0,y0),(x,y),(0,255,255),2)

            #发送坐标
            ex,ey=(x-x0,y-y0)
            #ex,ey=(200,0)#测试用
            msg =f"@{ex},{ey}\n"
            ser.write(msg.encode("utf-8"))
        else:
            cv2.putText(display_frame, "No Target Found", (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)
            #发送坐标
            ser.write(b"@0,0\n")


        cv2.imshow("1",display_frame)
        if cv2.waitKeyEx(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
