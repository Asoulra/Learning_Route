from ultralytics import YOLO
import cv2
import numpy as np
import serial
import time

def open_serial():
    ser = serial.Serial('COM3', 9600)
    if not ser.is_open:
        return None
    print("Serial opened:", ser.name)
    return ser

def send_serial(ser, data):
    if not hasattr(send_serial, 'last_send_time'):#先定义一个属性来记录上次发送时间
        send_serial.last_send_time = 0
    ser.write(data.encode("utf-8"))
    if time.time() - send_serial.last_send_time > 1:  #每1秒终端打印一次数据
        send_serial.last_send_time = time.time()
        print("send data:", data)


def main():
    model = YOLO("model/yolov8n-pose.pt")  # pose 模型
    ser = open_serial()#打开串口
    if not ser:
        print("Failed to open serial port")
        return

    tick = time.time()
    cap = cv2.VideoCapture(0)

    while True:
        ret,frame = cap.read()
        if not ret:
            print("No find video")
            break
        #在画面中心画一个十字，作为参考点
        h,w = frame.shape[:2]
        x0,y0 = w/2,h/2
        cv2.line(frame,(int(x0-10),int(y0)),(int(x0+10),int(y0)),(255,255,255),1)
        cv2.line(frame,(int(x0),int(y0-10)),(int(x0),int(y0+10)),(255,255,255),1)


        if time.time() - tick > 1:  #每1秒处理一次帧
            tick = time.time()
            results = model.track(frame, persist=True, verbose=True)  #检测模式，关闭日志输出
        else:
            results = model.track(frame, persist=True,verbose=False)  #跟踪模式，持续跟踪，关闭日志输出
        
        face_detected = False
        if results:
            result = results[0]  #获取第一帧的结果
            max_conf_idx = 0  #默认置信度最高的目标索引为0
            if result.boxes is not None and result.keypoints is not None: # 检查是否有检测到的目标
                if result.boxes.conf.numel() > 0:#type: ignore  #检查是否有检测到的目标
                    max_conf_idx = result.boxes.conf.argmax().item()  # 找到置信度最高的目标索引
            kpts = np.asarray(result.keypoints.xy.cpu()) #type: ignore  #强制转化为numpy数组
            if len(kpts) > max_conf_idx:
                kpt = kpts[max_conf_idx]  #type: ignore  #获取置信度最高的目标的关键点
            if len(kpt) >= 3:#找出鼻子、左眼、右眼的坐标，计算脸部中心点
                nose = kpt[0]
                left_eye = kpt[1]
                right_eye = kpt[2]

                #过滤掉未检测到的点
                valid = [p for p in [nose, left_eye, right_eye] if p[0] > 0 and p[1] > 0]
                if valid:
                    face_center = np.mean(valid, axis=0)  #计算脸部中心点
                    cx,cy=face_center[0],face_center[1]
            

                #标出脸部中心位置
                    cv2.line(frame,(int(cx),int(cy)),(int(x0),int(y0)),(0,255,0),1)
                    cv2.circle(frame,(int(cx),int(cy)),5,(0,0,255),-1)
                    cv2.putText(frame,f"piont is {(int(cx),int(cy))}",(int(0),int(20)),cv2.FONT_HERSHEY_SIMPLEX,0.75,(0,255,0),2)
            
                    ex,ey = int(cx)-int(x0),int(cy)-int(y0)
                    send_serial(ser, f"@{ex},{ey}")
        # 如果没有检测到人脸，发送默认数据
        if not face_detected:
            send_serial(ser, f"@{0},{0}")
        cv2.imshow("pose",frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    cv2.destroyAllWindows()
    send_serial(ser, f"@{0},{0}")


if __name__ == "__main__":
    main()